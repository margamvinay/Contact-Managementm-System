# Contact-Management-System

## Add, Update, and Delete contacts and save them in a database.<br><br>
<img src = "https://github.com/kanchitank/Contact-Management-System/blob/master/images/CMS.JPG" width="700">
<br><br>

### Add Contact:<br>
<img src = "https://github.com/kanchitank/Contact-Management-System/blob/master/images/AddContact.JPG" width="700">
<br><br>

### Update Contact:<br>
<img src = "https://github.com/kanchitank/Contact-Management-System/blob/master/images/UpdateContact.JPG" width="700">
<br><br>
